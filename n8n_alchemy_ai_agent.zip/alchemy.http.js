module.exports = {
  path: '/alchemy',
  method: 'POST',
  handler(req, res) {
    const alchemy = require('./alchemy.logic.js');
    const stage = req.body.stage || 'calcination';
    const result = alchemy.transmute(stage);
    res.json({ result });
  }
};