# Alchemy AI Agent for n8n

This AI agent simulates symbolic alchemical operations, transmutation paths, and metaphysical interpretations via HTTP POST requests.

## Files
- `alchemy.workflow.json`: n8n workflow for alchemical interaction
- `alchemy.http.js`: HTTP trigger handler
- `alchemy.logic.js`: Symbolic alchemy engine
- `manifest.json`: Agent metadata and description
