const stages = {
  calcination: "Burning away ego, pride, and illusions. Element: Fire.",
  dissolution: "Dissolving rigidity and emotional blockages. Element: Water.",
  separation: "Identifying what must be kept or discarded. Element: Air.",
  conjunction: "Union of opposites. Alchemical marriage. Element: Earth.",
  fermentation: "Spiritual rebirth through decay. Element: Aether.",
  distillation: "Refining of the essence. Mental purification. Element: Spirit.",
  coagulation: "Completion. Manifestation of the Philosopher's Stone."
};

function transmute(stage) {
  const key = stage.toLowerCase();
  return {
    stage: key,
    meaning: stages[key] || "Unknown alchemical stage.",
    affirmation: `You are now entering the stage of ${key}. Accept its trials and lessons.`
  };
}

module.exports = { transmute };
