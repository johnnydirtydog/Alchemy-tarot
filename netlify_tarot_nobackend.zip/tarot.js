
const tarotDeck = [
    { name: "The Fool", meaning: "New beginnings, spontaneity, free spirit." },
    { name: "The Magician", meaning: "Manifestation, resourcefulness, power." },
    { name: "The High Priestess", meaning: "Intuition, sacred knowledge, divine feminine." },
    { name: "The Empress", meaning: "Femininity, beauty, nature, nurturing." },
    { name: "The Emperor", meaning: "Authority, structure, control, fatherhood." },
    { name: "The Hierophant", meaning: "Tradition, conformity, morality, ethics." },
    { name: "The Lovers", meaning: "Love, union, partnerships, duality." },
    { name: "The Chariot", meaning: "Victory, action, determination, control." }
];

function drawCard() {
    const card = tarotDeck[Math.floor(Math.random() * tarotDeck.length)];
    document.getElementById("card-display").innerHTML = `<strong>${card.name}</strong><br>${card.meaning}`;
}
